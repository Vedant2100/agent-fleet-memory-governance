#!/bin/bash
set -euxo pipefail

cd /testbed

# Apply test patch if exists
if [ -f /test.patch ]; then
    git apply /test.patch || echo "Test patch already applied or failed"
fi

# Apply model patch
git apply /patch.diff

# Run tests (python)
python tests/runtests.py -v
