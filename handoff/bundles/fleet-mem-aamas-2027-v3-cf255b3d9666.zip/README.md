# Fleet-Mem evidence bundle

Status: PROVISIONAL — incomplete snapshot. Snapshot captured while the Slurm job was still running; job state was RUNNING.
Slurm child steps marked failed at collection: 289898.5, 289898.11. See slurm-accounting.json for the complete accounting records.
Experiment code commit: 1cedbc0035cb867cfebde398019e313c2a5b02cb.
Core treatments: A_NO_MEMORY, B_SHARE_ALL, C_RANDOM_MATCHED, D_JEV_WRITE, E_JEV_WRITE_READ, F_ORACLE_RELATED_CEILING.
The earlier G_LLM_WRITE arm is unrun and outside this amended A–F core handoff.
The ten-target A/F signal gate was frozen with 3/10 executable discordances. A/F grades include the supplemental test-file-filtered regrade of already-generated worker patches.
Treatment grades collected: 29/40. Read runtime/results/development/paper-treatments-luna/attempt-0003/treatment_results.jsonl for per-task outcomes.

Contents: runtime/ contains raw workers, predictions, API response metadata, canonical grades and logs, baseline failures, target/source manifests, governor decisions, and failed attempts. source/ contains repository code, prompts, configurations, protocol, and analysis scripts. The frozen experiment code commit is recorded above and in environment.json. archive-member-inventory.json records per-file checksums.

Interpretation: these are development pilot outcomes, not a confirmatory effect estimate. Report unresolved patches as legitimate outcomes; inspect FAIL_TO_PASS and PASS_TO_PASS counts and exposure differences. The API exposes the requested worker model alias gpt-6-luna, not an underlying checkpoint build identifier.

Outstanding validation issues:
- missing 11 treatment grades
- final treatment summary is absent or not COMPLETE with 40 grades
- six-arm paper table is absent
- Slurm job state is RUNNING
