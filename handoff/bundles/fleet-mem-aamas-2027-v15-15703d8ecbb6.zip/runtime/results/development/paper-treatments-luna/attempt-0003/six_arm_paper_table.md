# Luna six-arm paper table

Targets: 10 · Treatment grades: 40 · Signal: ORACLE_SIGNAL_PRESENT (3/10)

| Arm | Resolved | Applied | F2P passed / total | P2P passed / total |
|---|---:|---:|---:|---:|
| No-Memory | 2/10 | 10/10 | 9 / 48 | 2145 / 2145 |
| Share-All | 1/10 | 10/10 | 7 / 48 | 2025 / 2145 |
| Random-Matched | 1/10 | 10/10 | 8 / 48 | 2025 / 2145 |
| Jev Write | 1/10 | 10/10 | 13 / 48 | 2025 / 2145 |
| Jev Write+Read | 1/10 | 10/10 | 7 / 48 | 2025 / 2145 |
| Oracle Ceiling | 1/10 | 10/10 | 8 / 48 | 2025 / 2145 |

## Per-target outcomes

| Target | No-Memory | Share-All | Random-Matched | Jev Write | Jev Write+Read | Oracle Ceiling |
|---|---:|---:|---:|---:|---:|---:|
| sympy__sympy-19235 | resolved; F2P 1/1 | resolved; F2P 1/1 | resolved; F2P 1/1 | resolved; F2P 1/1 | resolved; F2P 1/1 | resolved; F2P 1/1 |
| sympy__sympy-21203 | resolved; F2P 3/3 | unresolved; F2P 1/3 | unresolved; F2P 2/3 | unresolved; F2P 2/3 | unresolved; F2P 1/3 | unresolved; F2P 1/3 |
| django__django-35356 | unresolved; F2P 0/1 | unresolved; F2P 0/1 | unresolved; F2P 0/1 | unresolved; F2P 0/1 | unresolved; F2P 0/1 | unresolved; F2P 0/1 |
| sympy__sympy-16342 | unresolved; F2P 1/11 | unresolved; F2P 1/11 | unresolved; F2P 1/11 | unresolved; F2P 1/11 | unresolved; F2P 1/11 | unresolved; F2P 2/11 |
| sympy__sympy-16946 | unresolved; F2P 0/6 | unresolved; F2P 0/6 | unresolved; F2P 0/6 | unresolved; F2P 4/6 | unresolved; F2P 0/6 | unresolved; F2P 0/6 |
| sympy__sympy-21309 | unresolved; F2P 1/2 | unresolved; F2P 1/2 | unresolved; F2P 1/2 | unresolved; F2P 1/2 | unresolved; F2P 1/2 | unresolved; F2P 1/2 |
| django__django-34176 | unresolved; F2P 1/6 | unresolved; F2P 1/6 | unresolved; F2P 1/6 | unresolved; F2P 2/6 | unresolved; F2P 1/6 | unresolved; F2P 1/6 |
| sympy__sympy-16953 | unresolved; F2P 0/11 | unresolved; F2P 0/11 | unresolved; F2P 0/11 | unresolved; F2P 0/11 | unresolved; F2P 0/11 | unresolved; F2P 0/11 |
| scikit-learn__scikit-learn-13771 | unresolved; F2P 2/5 | unresolved; F2P 2/5 | unresolved; F2P 2/5 | unresolved; F2P 2/5 | unresolved; F2P 2/5 | unresolved; F2P 2/5 |
| sympy__sympy-9384 | unresolved; F2P 0/2 | unresolved; F2P 0/2 | unresolved; F2P 0/2 | unresolved; F2P 0/2 | unresolved; F2P 0/2 | unresolved; F2P 0/2 |
